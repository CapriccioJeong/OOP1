import csv
import os

def get_csv_writer(filename, rows, delimiter):
    with open(filename, 'w') as csvfile:
        fieldnames = rows[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, delimiter=delimiter)
        writer.writeheader()
        for row in rows:
            try:
                writer.writerow(row)
            except Exception as detail:
                print(type(detail))
                print(detail)

def get_csv_reader(filename, delimiter):
    reader = []
    if not os.path.isfile(filename):
        csvfile = open(filename, "w")
    else:
        csvfile = open(filename, "rb")
        reader = csv.DictReader(csvfile, delimiter=delimiter)
    return list(reader)

class Book:
    csvfile = ID, Author, Title, Publisher, PublishedYear, Location, PurchaseDate, RentalDate
